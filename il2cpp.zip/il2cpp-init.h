#pragma once

extern void *il2cpp_handle;

void init_il2cpp_api();

